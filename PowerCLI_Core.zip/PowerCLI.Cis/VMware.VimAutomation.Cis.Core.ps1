[VMware.VimAutomation.Sdk.Interop.V1.CoreServiceFactory]::CoreService.OnImportModule(
    "VMware.VimAutomation.Cis.Core.Commands",
    (Split-Path $script:MyInvocation.MyCommand.Path));